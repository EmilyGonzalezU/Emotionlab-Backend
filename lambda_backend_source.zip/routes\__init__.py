"""Blueprints HTTP de EmotionLab."""
